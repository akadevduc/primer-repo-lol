﻿
public class Perro
{
    private string nombre, raza, altura;

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public string Raza
    {
        get { return raza; }
        set { raza = value; }
    }

    public string Altura
    {
        get { return altura; }
        set { altura = value; }
    }
    public Perro(string nombre, string raza, string altura)
    {
        this.nombre = nombre;
        this.raza = raza;
        this.altura = altura;
    }

    public void Dormir()
    {
        Console.WriteLine($"{nombre} está durmiendo... Zzz");
    }

    public void Ladrar()
    {
        Console.WriteLine($"{nombre} dice Guau Guau Guau");
    }

    public string Comer(string carne)
    {
        return $"{nombre} mide {altura} y comerá: {carne}";
    }

}


