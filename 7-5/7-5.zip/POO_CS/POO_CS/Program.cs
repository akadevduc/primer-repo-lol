﻿Perro perro1 = new Perro("Coco","Boxer","40cm");
Console.WriteLine("--- Perro 1 ---");
perro1.Dormir();
string resultadoComer = perro1.Comer("Hamburguesa");
Console.WriteLine(resultadoComer);
